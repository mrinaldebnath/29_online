package client1;

import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Frame1 extends javax.swing.JFrame {

    public Frame1() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        b1 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        b5 = new javax.swing.JButton();
        b6 = new javax.swing.JButton();
        b7 = new javax.swing.JButton();
        b8 = new javax.swing.JButton();
        Player2 = new javax.swing.JLabel();
        b9 = new javax.swing.JButton();
        b10 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        b1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b1ActionPerformed(evt);
            }
        });

        b2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b2ActionPerformed(evt);
            }
        });

        b3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b3ActionPerformed(evt);
            }
        });

        b4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b4ActionPerformed(evt);
            }
        });

        b5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b5ActionPerformed(evt);
            }
        });

        b6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b6ActionPerformed(evt);
            }
        });

        b7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b7ActionPerformed(evt);
            }
        });

        b8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b8ActionPerformed(evt);
            }
        });

        b9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b9ActionPerformed(evt);
            }
        });

        b10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b10ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(239, 239, 239)
                .addComponent(Player2, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(285, 285, 285)
                .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(285, 285, 285)
                .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Player2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(b10, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(b9, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(b1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b2, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b3, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b5, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b6, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b8, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    int k = 0;
    public char[] c={'j','9','a','t','k','q','8','7'};
    public String p=null;
    public boolean x=true;
    ImageIcon ic = new ImageIcon(getClass().getResource("/images/w.jpg"));
    int a[] = {0, 1, 2, 3, 4, 5, 6, 7}; 
    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
        if(x){
        if(p==null)
        {
            b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        }
        else if(p.charAt(1)==im[a[0]].charAt(1))
    {   b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
    }
        else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
            
    }
    }//GEN-LAST:event_b1ActionPerformed
    
    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
       if(x){ if(p==null)
        {
           b9.setIcon(img[a[1]]);
        p3 = "p2" + im[a[1]];

        for (int i = 1; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }

        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        
        }
     else if(p.charAt(1)==im[a[1]].charAt(1))
    {    b9.setIcon(img[a[1]]);
        p3 = "p2" + im[a[1]];

        for (int i = 1; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }

        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
        
    }
        else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
       }
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
        if(x){if(p==null)
        {
           b9.setIcon(img[a[2]]);
        p3 = "p2" + im[a[2]];
        for (int i = 2; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }

        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        
        
        }
        else if(p.charAt(1)==im[a[2]].charAt(1))    
    {    b9.setIcon(img[a[2]]);
        p3 = "p2" + im[a[2]];
        for (int i = 2; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }

        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
       for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
        }
         else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
        }
    }//GEN-LAST:event_b3ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
        if(x){if(p==null)
        {
             b9.setIcon(img[a[3]]);
        p3 = "p2" + im[a[3]];
        for (int i = 3; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        
        }
        else if(p.charAt(1)==im[a[3]].charAt(1))
    {    b9.setIcon(img[a[3]]);
        p3 = "p2" + im[a[3]];
        for (int i = 3; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
    }
         else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
    }
    }//GEN-LAST:event_b4ActionPerformed

    private void b5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b5ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
     if(x)  { if(p==null)
        {
             b9.setIcon(img[a[4]]);
        p3 = "p2" + im[a[4]];
        for (int i = 4; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        
        }
        else if(p.charAt(1)==im[a[4]].charAt(1))
    {    b9.setIcon(img[a[4]]);
        p3 = "p2" + im[a[4]];
        for (int i = 4; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
        
    } else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
     }
    }//GEN-LAST:event_b5ActionPerformed

    private void b6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b6ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
      if(x) { if(p==null)
        {
            b9.setIcon(img[a[5]]);
        p3 = "p2" + im[a[5]];
        for (int i = 5; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
        
        }
        else if(p.charAt(1)==im[a[5]].charAt(1))
    {    b9.setIcon(img[a[5]]);
        p3 = "p2" + im[a[5]];
        for (int i = 5; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;

        c1.oos(p3);
      for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
    }
       else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
    }
    }//GEN-LAST:event_b6ActionPerformed

    private void b7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b7ActionPerformed
        // TODO add your handling code here:
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
     if(x) {  if(p==null)
        {
            b9.setIcon(img[a[6]]);
        p3 = "p2" + im[a[6]];
        for (int i = 6; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        
        }
        else if(p.charAt(1)==im[a[6]].charAt(1))
    {    b9.setIcon(img[a[6]]);
        p3 = "p2" + im[a[6]];
        for (int i = 6; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
      for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }
            b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
    }
      else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[a[0]]);
        p3 = "p2" + im[a[0]];
        for (int i = 0; i < 7 - k; i++) {
            b[i].setIcon(img[a[i + 1]]);
            a[i] = a[i + 1];
        }
        b[7 - k].setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
    }
    }//GEN-LAST:event_b7ActionPerformed

    private void b8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b8ActionPerformed
        // TODO add your handling code here:
     if(x) {  if(p==null)
        {
             b9.setIcon(img[7]);
        b8.setVisible(false);
        p3 = "p2" + im[7];
        k++;
        c1.oos(p3);
        
        }
        else if(p.charAt(1)==im[7].charAt(1))
    {    b9.setIcon(img[7]);
        b8.setVisible(false);
        p3 = "p2" + im[7];
        k++;
        c1.oos(p3);
       for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }  b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
    }
      else
        {
            int y=0;
            for(int j=0;j<=7-k;j++)
            {
                if((p.charAt(1))!=im[a[j]].charAt(1))
                {
                    y++;
                }
            }
            if(y==8-k)
            {
                b9.setIcon(img[7]);
        p3 = "p2" + im[7];
        
        b8.setVisible(false);
        k++;
        c1.oos(p3);
        x=false;
        b9.setIcon(ic);
            b10.setIcon(ic);
            p=null;
            p3=null;
            }
        }
    }   
        //this.setVisible(false);
    }//GEN-LAST:event_b8ActionPerformed

    private void b9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b9ActionPerformed

    private void b10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b10ActionPerformed

    int count = 0;
    public String[] imag = new String[8];
    public String[] card1 = {"jc", "9c", "ac", "tc", "kc", "qc", "8c", "7c", "jh", "9h", "ah", "th", "kh", "qh", "8h", "7h", "js", "9s", "as", "ts", "ks", "qs", "8s", "7s", "jd", "9d", "ad", "td", "kd", "qd", "8d", "7d"};
    Deck testDeck = new Deck();
    int round = 8;
    public ImageIcon[] img = new ImageIcon[8];
    PlayerHands PlayerHands = new PlayerHands(testDeck, round);
    public String[] im = new String[8];
    public String p3 = null;
    Client1 c1 = new Client1();
    String t=null;

    public void text(String name) {
        Player2.setText(name);
    }

    public void printy(String s, int n) {
        // Client1 c=new Client1();
        JButton[] b = {b1, b2, b3, b4, b5, b6, b7, b8};
        imag[n] = s;
        int count1 = 0;
        if (n == 7) {
            for (int y = 0; y < 32; y++) {
                for (int i = 0; i < 8; i++) {
                    if (imag[i].equals(card1[y])) {
                        im[count1] = imag[i];
                        img[count1] = new ImageIcon(getClass().getResource("/images/" + imag[i] + ".jpg"));
                        ImageIcon iic = new ImageIcon(getClass().getResource("/images/" + imag[i] + ".jpg"));
                        b[count1].setIcon(iic);
                        count1++;
                    }
                }
            }
        }
    }

    public void setp2(String s) throws InterruptedException {
        if(p==null)
        {
            p=s;
        }
        
            ImageIcon iic = new ImageIcon(getClass().getResource("/images/" + s + ".jpg"));
            b10.setIcon(iic);
            //b9.removeAll();
        if(p3==null)x=true;
        if(p3!=null)
        {
            if(p3.charAt(3)!=p.charAt(1))x=true;
            else{for(int j=0;j<8;j++)
        {
            if(c[j]==p.charAt(0))
            {    
                x=false;
                break;
            }
            else if(c[j]==p3.charAt(2))
            {
                x=true;
                break;
            }
        }  }
            c1.slp();
          b9.setIcon(ic);
          b10.setIcon(ic);
            p=null;
            p3=null;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frame1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Frame1().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Player2;
    private javax.swing.JButton b1;
    private javax.swing.JButton b10;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JButton b5;
    private javax.swing.JButton b6;
    private javax.swing.JButton b7;
    private javax.swing.JButton b8;
    private javax.swing.JButton b9;
    // End of variables declaration//GEN-END:variables
}
