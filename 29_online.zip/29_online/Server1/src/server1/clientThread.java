/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server1;

import java.awt.Frame;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Serializable;
import java.net.Socket;

/**
 *
 * @author MRINAL
 */
public class clientThread extends Thread {

  private DataInputStream is = null;
  private PrintStream os = null;
  private Socket clientSocket = null;
  private final clientThread[] threads;
  private int maxClientsCount;
  static Deck d=new Deck();
  static int k=0;
  static PlayerHands p=new PlayerHands(d, 8);
  public clientThread(Socket clientSocket, clientThread[] threads) {
    this.clientSocket = clientSocket;
    this.threads = threads;
    maxClientsCount = threads.length;
  }

  public void run() {
    int maxClientsCount = this.maxClientsCount;
    clientThread[] threads = this.threads;

    try {
      /*
       * Create input and output streams for this client.
       */
      Card[][] po=new Card[2][8];
      po[0]=p.playerOneCards;
      po[1]=p.playerTwoCards;
      is = new DataInputStream(clientSocket.getInputStream());
      os = new PrintStream(clientSocket.getOutputStream());
      os.println("Enter your name.");
      String name = is.readLine().trim();
      os.println("Hello " + name
          + " to our chat room.\nTo leave enter /quit in a new line");
        k++;
      if(k==2){
          for (int j = 0; j < maxClientsCount; j++) {
           if (threads[j] != null) {
               for(int l=0;l<8;l++)
               {threads[j].os.println(po[j][l]);}
      }}}
      for (int i = 0; i < maxClientsCount; i++) {
        if (threads[i] != null && threads[i] != this) {
          threads[i].os.println("*** A new user " + name
              + " entered the chat room !!! ***");
          threads[i].os.println("Player 2:"+name);   }     
        }
      
      
      while (true) {
       /*  try
      {
          for(int l=0;l<8;l++)
               {os.println(po[k][l]);}
          k++;
      }catch(Exception ex){} */
        String line = is.readLine();
        
        if (line.startsWith("/quit")) {
          break;
        }
        
        else if(line.startsWith("p2"))
        
            for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] != null && threads[i]!=this) {
            threads[i].os.println(line);
          }
        }
        
        else
       
            for (int i = 0; i < maxClientsCount; i++) {
          if (threads[i] != null) {
            threads[i].os.println("<" + name + " told : " + line);
          }
        }
        }
      
      
     for (int i = 0; i < maxClientsCount; i++) {
        if (threads[i] != null && threads[i] != this) {
          threads[i].os.println("*** The user " + name
              + " is leaving the chat room !!! ***");
        }
      }
      os.println("*** Bye " + name + " ***");

      /*
       * Clean up. Set the current thread variable to null so that a new client
       * could be accepted by the server.
       */
      for (int i = 0; i < maxClientsCount; i++) {
        if (threads[i] == this) {
          threads[i] = null;
        }
      }

      /*
       * Close the output stream, close the input stream, close the socket.
       */
      is.close();
      os.close();
      clientSocket.close();
    } catch (IOException e) {
    }
  }
}
